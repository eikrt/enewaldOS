#/bin/sh

source .env
lua server.lua
