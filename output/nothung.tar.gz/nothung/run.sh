#/bin/sh

source .env

lua client.lua
